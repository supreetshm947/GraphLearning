This file Contains the Cora and Citeseer datasets [1] for node classification.
We have already split each dataset into training and evaluation data.

For Task 4 you can reuse the ENZYMES and NCI1 datasets provided for Sheet 1.

References:

[1] Sen, Prithviraj, et al. "Collective classification in network data." AI magazine 29.3 (2008): 93-93.
